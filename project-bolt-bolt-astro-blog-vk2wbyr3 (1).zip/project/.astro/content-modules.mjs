
export default new Map([
["src/content/blog/using-mdx.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Fblog%2Fusing-mdx.mdx&astroContentModuleFlag=true")]]);
		